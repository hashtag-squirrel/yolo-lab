# Yolo project > 2026-03-11 11:43am
https://universe.roboflow.com/alitas-workspace/yolo-project-4wtor

Provided by a Roboflow user
License: CC BY 4.0

